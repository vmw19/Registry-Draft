let salon={
    name: "Grooming Pets",
    address:{
        street: "123 Happy Pets Lane",
        zipcode: "22414",
        number: "262-K",
    },
    hours: {
        open: "5:00 a.m.",
        close: "11:00 p.m.",
    },
    pets: [
    {
        name: "Scobby",
        age: 60;
        gender: "Male",
        breed: "Dane",
        service: "Grooming",
        owner: "Shaggy",
        phone: 561 - 953 - 1551
    },

    {
        name: "Rocky",
        age: 20,
        gender: "Female",
        breed: "Dane",
        service: "Grooming",
        owner: "RockStar",
        phone: 581 - 953 - 1651
    },

    {
        name: "Cujo",
        age: 25,
        gender: "Male",
        breed: "Pitbull",
        service: "Grooming",
        owner: "Josh",
        phone: 181 - 953 - 1251
    },

    {
        name: "Tiny",
        age: 31,
        gender: "Female",
        breed: "Poodle",
        service: "Grooming",
        owner: "Kaleb",
        phone: 561 - 953 - 1551
    },
}

console.log(salon.pets);

function displayPetNames(){
    for (let i = 0; i < salon.pets.length; i++) {
        console.log(salon.pets[i].age)
        //travel the array
        //display in the console the names
        console.log(salon.pets[i].name)
    }
}
window.onload = displayPetAges;

//create the constructor
function Pet(name, age, gender, breed) {
    this.name = name;
    this.age = age;
    this.gender = gender;
    this.breed = breed;
    this.service = service;
}
//create three pets using the constructor
let scooby'new Pet("Scooby" );

//getting the inputs from the html
let petName= document.getElementById("txtName");
let displayPetAge= document.getElementById("txtAge");
let petGender= document.getElementById("txtGener");
let petBreed= document.getElementById("txtBreed");
let petService= document.getElementById("selService");

function register(){
    console.log ("Register");
    let thePet=new Pet (petName.value,petAge.value, petGender.value, petBreed.value, petService.value);
    console.log(thePet);
    salon.pets.push(thePet);
    console.log(salon.pets);
    showPetsCards();
    alert("Congrats! You have registered a new pet!");
}
function showPetsCards
    document.getElementById("petList").innerHTML=""
    for(let i=0);i,salon.pets.length;i++){
        document.getElementById("petList").innerHTML +=createcard(salon.pets[i]);
    }
    function createCard(pet){
        return `
        <div class="pet-card">
            <h3>${pet.name}</h3>
            <p>Age: ${pet.age}</p>
            <p>Gender: ${pet.gender}</p>
            <p>Service: ${pet.service}</p>
    }
    </div>
